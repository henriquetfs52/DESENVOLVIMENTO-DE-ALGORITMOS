#include <stdio.h>
#include <stdlib.h>

int main()
{
	int matriz[10][15];
	int linha, coluna;
	
	for (linha=0; linha < 10;){
		for (coluna = 0; coluna <15;){
			matriz[linha][coluna] = (rand()%100) + 1;
			coluna++;
		}

		linha++;
	}

	for (linha =0; linha <10;){
		for (coluna = 0;coluna <15;){
			printf("%d", matriz[linha][coluna]);
			coluna++;
		}
		printf("\n");
		linha++;
	}
	
	system("pause");	
	return 0;
}
