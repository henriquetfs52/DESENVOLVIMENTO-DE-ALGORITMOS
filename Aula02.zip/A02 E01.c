#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(void) {

	setlocale(LC_ALL, "Portuguese");

    float n1;
    float n2;
    float soma;

    printf("Digite n1: \n");
    scanf("%f", &n1);

    printf("Digite n2: \n");
    scanf("%f", &n2);

    soma = n1 + n2;

    printf("O total da soma � : %2.f\n", soma);

	system("pause");
    return 0;
    
}
