#include <stdio.h>
#include <stdlib.h>

int main() 
{
	int x = 5, *Pint;
	float f = 2.00, *Pfloat;
	char c = 'a', *Pchar;
	
	Pint = &x;
	Pfloat = &f;
	Pchar = &c;
	
	(*Pint) = 6;
	(*Pfloat) = 5.00;
	(*Pchar) = 'b';
	
	printf("[ %d %.2f %c ]", x, f, c);
	
	
	
	
	system("pause");	
	return 0;
}
