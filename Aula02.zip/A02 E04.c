#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(void) {

	setlocale(LC_ALL, "Portuguese" );

	float km;
	float dias;
	float total;

	printf("Digite a quantidade de km");
	scanf("%f", &km);
	printf("Digite a quantidade de dias");
	scanf("%f", &dias);

	total = dias * 60 + km * 0.15;

	printf("o pre�o � R$: %.2f \n", total);

	system("pause");
	return 0;


}
