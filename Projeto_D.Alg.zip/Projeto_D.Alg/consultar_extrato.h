#ifndef CONSULTAR_EXTRATO_H
#define CONSULTAR_EXTRATO_H

#include "login.h"

void consultar_extrato(char *usuario_ativo) {
    char linha[200], nome[50], cpf[12], senha[7], data[20], moeda[10];
    char ativo[50], nome_min[50];
    char sinal;
    double valor, ct, tx, real, btc, eth, xrp;
    double r, b, e, x;
    int total = 0, achou = 0;
    FILE *arquivo;

    strcpy(ativo, usuario_ativo);
    minusculo(ativo);

    // Procura o nome e o CPF do usuario no contas.txt
    arquivo = fopen("contas.txt", "r");
    if (arquivo == NULL) {
        printf("Nao foi possivel abrir o arquivo contas.txt\n");
        return;
    }

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (sscanf(linha, "%49[^_]_%11[^_]_%6[^_]_%lf_%lf_%lf_%lf",
                   nome, cpf, senha, &r, &b, &e, &x) == 7) {
            strcpy(nome_min, nome);
            minusculo(nome_min);
            if (strcmp(ativo, nome_min) == 0) {
                achou = 1;
                break;
            }
        }
    }
    fclose(arquivo);

    if (achou == 0) {
        printf("Conta nao encontrada.\n");
        return;
    }

    printf("\nNome: %s\n", nome);
    printf("CPF: %.3s.%.3s.%.3s-%.2s\n\n", cpf, cpf + 3, cpf + 6, cpf + 9);

    // Mostra as operacoes do usuario
    arquivo = fopen("extrato.txt", "r");
    if (arquivo == NULL) {
        printf("Nenhuma operacao registrada.\n");
        return;
    }

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        // So usa a linha se conseguiu ler os 11 campos
        if (sscanf(linha, "%49[^_]_%19[^_]_%c_%lf_%9[^_]_%lf_%lf_%lf_%lf_%lf_%lf",
                   nome, data, &sinal, &valor, moeda, &ct, &tx, &real, &btc, &eth, &xrp) == 11) {
            minusculo(nome);
            if (strcmp(nome, ativo) == 0) {
                printf("%s %c %9.2f %-4s CT: %9.2f TX: %4.2f REAL: %9.2f BTC: %9.6f ETH: %9.6f XRP: %9.6f\n",
                       data, sinal, valor, moeda, ct, tx, real, btc, eth, xrp);
                total++;
            }
        }
    }
    fclose(arquivo);

    if (total == 0) {
        printf("Nenhuma operacao registrada.\n");
    }
}

#endif
