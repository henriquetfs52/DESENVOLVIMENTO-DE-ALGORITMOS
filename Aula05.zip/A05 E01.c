#include <stdio.h>
#include <stdlib.h>

int main() 
{
	int vetor[10];
	int maior = -99999, indexM = 0;
	int index;
	
	for (index = 0; index < 9;){
		printf("Digite um numero");
		scanf("%d", &vetor[index]);
		if (vetor[index] > maior){
			maior = vetor[index];
			indexM = index;
		}
	index++;
	}
	
	printf("maior: vetor[%d] %d", indexM, maior);
	system("pause");	
	return 0;
}
