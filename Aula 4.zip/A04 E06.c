#include <stdio.h>
#include <stdlib.h>
int potencia(int n, int m){
		if(m<=0){
			return 1;}
		else{
		    return(n * potencia(n,m-1));}

}


int main(int argc, char *argv[]) 
{
	printf("%d", potencia(5,2));
	

	system("pause");	
	return 0;
}
