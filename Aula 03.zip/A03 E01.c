#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL, "Portuguese");
	
	float km;
	float total;
	
	printf("Digite os kms");
	scanf("%f", &km);
	
	
	if (km > 200){
		total = km * 0.45;
	}
	
	else {
    total = km * 0.5;
    
	}
	
	printf("O pre�o total � %.2f reais", total);

	system("pause");	
	return 0;
}
