#include <stdio.h>
#include <stdlib.h>

int main()
{
	int soma=0, cont=0, media, n;
	do {
		printf("Digite um numero: ");
		scanf("%d", &n);
		if (n!= 0){
		soma +=n;
		cont ++;
	}
} while (n!=0);

media = soma/cont;
printf("A soma dos numeros:%d\n", soma);
printf("A quantidade de numeros:%d\n", cont);
printf("A media dos numeros:%d\n", media);

	system("pause");	
	return 0;
}
