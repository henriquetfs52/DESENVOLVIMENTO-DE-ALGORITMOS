#include <stdio.h>
#include <stdlib.h>

int main()
{
	char x[]="1", y[]="2", z[]="3", w[]="4";
	int res;
	
	res = atoi(x) + atoi(y) + atoi(z);
	
	printf("%d", res);
	
	
	system("pause");	
	return 0;
}
