#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
	float a = 6, b = 7, res, *Pa, *Pb;
	
	Pa = &a;
	Pb = &b;
	
	res = (*Pa) + (*Pb);
	
	printf(" %.0f ", res);
	

	system("pause");	
	return 0;
}
