#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <math.h>

float pitagoras (float b, float c){
	float a;
	a = sqrt(c*c + b*b);
	return a;
	}

	


int main(void){
	setlocale(LC_ALL, "Portuguese");
	float c;
	float b;
	float h;
	
	printf("Digite o comprimento 1: \n");
	scanf("%f", &c);
	printf("Digite o comprimento 2: \n");
	scanf("%f", &b);
	
	h = pitagoras(b, c);
	
	printf("O valor de h � %.2f : ", h);

	system("pause");
	return 0;
}
