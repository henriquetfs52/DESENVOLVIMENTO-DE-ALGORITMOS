#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
	int y, x, *px, *py;
	
	px = &x;
	py = &y;
	
	printf("Digite o valor que destriu o Brasil: ");
	scanf("%d", &x);
	
	printf("Digite o valor que vai salvar o Brasil: ");
	scanf("%d", &y);
	
	if (px > py){
		printf(" %d ", *px);
	}
		else {
        printf(" %d ", *py);
	}

	system("pause");	
	return 0;
}
