#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(void) {

	setlocale(LC_ALL, "Portuguese" );
	
    float dias;
    float horas;
    float minutos;
    float segundos;
    float total;

    printf("Digite os dias: \n");
    scanf("%f", &dias);

    printf("Digite as horas: \n");
    scanf("%f", &horas);

    printf("Digite os minutos: \n");
    scanf("%f", &minutos);

    printf("Digite os segundos: \n");
    scanf("%f", &segundos);


    total = segundos + 60 * minutos + 3600 * horas + 86400 * dias;

    printf("O total da soma � : %f\n", total);

	system("pause");
    return 0;
}
