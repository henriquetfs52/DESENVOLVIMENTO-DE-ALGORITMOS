#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void){

	setlocale(LC_ALL, "Portuguese");


	int ano;
	printf("Digite um ano");
	scanf("%d", &ano);
	
	if ((ano % 400 ==0)|| (ano % 4 == 0 && ano % 100)){
		printf("O ano %d � bissexto \n", ano);
	}
	
	else {
		printf( "O ano %d n�o � bissexto \n", ano);
	}
		


	system("pause");	
	return 0;
}
