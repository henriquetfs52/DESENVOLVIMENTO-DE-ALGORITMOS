#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
	//fazer depois zzzzzz
	system("pause");	
	return 0;
}
