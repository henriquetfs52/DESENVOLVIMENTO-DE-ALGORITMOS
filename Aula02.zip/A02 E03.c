#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(void) {

	setlocale(LC_ALL, "Portuguese" );

	int a;
	int b;
	int temp;

	printf("Digite o valor de a \n");
	scanf("%d", &a);
	printf("Digite o valor de b \n");
	scanf("%d", &b);

	temp = a;
	a = b;
	b= temp;

	printf("a ="a);

	printf("b =" b);

	system("pause");

	return 0;

}
