#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>



int main()
{
	float nota1, nota2, nota3, media;
	char op;
	do{
		printf("Digite a primeira nota");
		scanf("%f", &nota1);
		printf("Digite a segunda nota");
		scanf("%f", &nota2);
		printf("Digite a terceira nota");
		scanf("%f", &nota3);
		media = (nota1 + nota2 + nota3)/3;
		printf("A madia final �:%.2f\n", media);
		printf("Deseja realizar outro calculo? (S/N):");
		scanf("%c", &op);
	} while (op =='s' || op=='S');
	
	system("pause");
	return 0;
	
}
