#ifndef CONSULTAR_SALDO_H
#define CONSULTAR_SALDO_H

#include "login.h"

void consultar_saldo(char *usuario_ativo) {
    char linha[200], nome[50], cpf[12], senha[7];
    char nome_min[50], ativo[50], senha_digitada[7];
    double reais, bitcoin, ethereum, ripple;
    int total = 0;
    FILE *arquivo;

    strcpy(ativo, usuario_ativo);
    minusculo(ativo);

    printf("\nDigite sua senha: ");
    scanf("%6s", senha_digitada);
	
    arquivo = fopen("contas.txt", "r");
    if (arquivo == NULL) {
        printf("Nao foi possivel abrir o arquivo contas.txt\n");
        return;
    }

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (sscanf(linha, "%49[^_]_%11[^_]_%6[^_]_%lf_%lf_%lf_%lf",
                   nome, cpf, senha, &reais, &bitcoin, &ethereum, &ripple) == 7) {
            total++;
            strcpy(nome_min, nome);
            minusculo(nome_min);

            if (strcmp(ativo, nome_min) == 0) {
                if (strcmp(senha_digitada, senha) != 0) {
                    printf("Senha incorreta.\n");
                    fclose(arquivo);
                    return;
                }
                printf("\nNome: %s\n", nome);
                printf("CPF: %.3s.%.3s.%.3s-%.2s\n\n", cpf, cpf + 3, cpf + 6, cpf + 9);
                printf("Reais: %.2f\n", reais);
                printf("Bitcoin: %.8f\n", bitcoin);
                printf("Ethereum: %.8f\n", ethereum);
                printf("Ripple: %.8f\n", ripple);
                fclose(arquivo);
                return;
            }
        }
    }

    fclose(arquivo);
    printf("Conta nao encontrada (%d contas lidas do arquivo).\n", total);
}

#endif
