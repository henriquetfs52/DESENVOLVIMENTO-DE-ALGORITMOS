#ifndef ATUALIZAR_COTACAO_H
#define ATUALIZAR_COTACAO_H

#include <stdio.h>
#include <stdlib.h>

// Le as 3 cotacoes do arquivo e guarda nas variaveis recebidas
// Retorna 1 se deu certo, 0 se deu erro
int ler_cotacoes(double *btc, double *eth, double *xrp) {
    FILE *arquivo = fopen("cot_moedas.txt", "r");
    if (arquivo == NULL) {
        printf("Nao foi possivel abrir o arquivo cot_moedas.txt\n");
        return 0;
    }

    if (fscanf(arquivo, "%lf_%lf_%lf", btc, eth, xrp) != 3) {
        printf("Arquivo cot_moedas.txt com formato errado\n");
        fclose(arquivo);
        return 0;
    }
    fclose(arquivo);

    // Cotacao zero ou negativa nao faz sentido
    if (*btc <= 0 || *eth <= 0 || *xrp <= 0) {
        printf("Lido do arquivo: %f %f %f\n", *btc, *eth, *xrp);   // teste
        printf("Cotacoes invalidas no arquivo cot_moedas.txt\n");
        return 0;
    }

    return 1;
}

// Gera um numero aleatorio entre -0.05 e +0.05 (de -5% a +5%)
double variacao() {
    return ((rand() % 1001) - 500) / 10000.0;
}

void atualizar_cotacao() {
    double btc, eth, xrp;
    FILE *arquivo;

    if (ler_cotacoes(&btc, &eth, &xrp) == 0) {
        return;
    }

    // Novo valor = valor antigo * (1 + variacao)
    btc = btc * (1 + variacao());
    eth = eth * (1 + variacao());
    xrp = xrp * (1 + variacao());

    arquivo = fopen("cot_moedas.txt", "w");
    if (arquivo == NULL) {
        printf("Nao foi possivel gravar o arquivo cot_moedas.txt\n");
        return;
    }
    fprintf(arquivo, "%.2f_%.2f_%.2f\n", btc, eth, xrp);
    fclose(arquivo);

    printf("\nCotacoes atualizadas:\n");
    printf("Bitcoin: R$ %.2f\n", btc);
    printf("Ethereum: R$ %.2f\n", eth);
    printf("Ripple: R$ %.2f\n", xrp);
}

#endif
