#include <stdio.h>
#include <stdlib.h>

int main()
{
	int vetor[10];
	int somaI = 0, somaP = 0, index;
	
	for (index = 0; index <10;){
		printf("Digite um numero");
		scanf("%d", &vetor[index]);
		if (index % 2 == 0){
			somaI = somaI + vetor[index];
			}

		if (vetor[index] % 2 == 0){
			somaP = somaP + vetor[index];
		}
		index++;
	}
	
	printf("Soma dos valores pares: %d\n", somaP);
	printf("Soma dos indices pares: %d\n", somaI);
			
	system("pause");	
	return 0;
}
