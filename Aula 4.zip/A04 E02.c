#include <stdio.h>
#include <stdlib.h>

int main() 
{


int cont=0,i;

while (cont<100){
	if (cont<=50){
	printf("%d\n", cont);
}
	else if (cont % 2 ==00) {
		printf("%d\n", cont);
	}
	cont++;

}
	system("pause");
	return 0;
	
}


