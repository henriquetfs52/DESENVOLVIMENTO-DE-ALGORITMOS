#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


int main(void)
{
	float a, b, total;
	int op;
	setlocale(LC_ALL, "Portuguese");

	
	printf("Digite o primeiro numero");
	scanf("%f", &a);
	
	printf("Digie o segundo numero");
	scanf("%f", &b);
	
	printf(" Digite sua opera��o: 0-Soma, 1-Subtra��o, 2-Multiplaca��o, 3-Divis�o");
	scanf("%d", &op);
	
	if (op == 0)
	{
		total = a + b;
		printf("Resultado: %2.f", total);
	}
	
	else if (op == 1)
	{
		total = a - b;
		printf("Resultado: %2.f", total);
	}
	
	else if (op == 2)
	{
		total = a * b;
		printf("Resultado: %2.f", total);
	}
	
	else if (op == 3)
	{
		total = a / b;
		printf("Resultado: %2.f", total);
	}
	
	else
	{
		printf("Opera��o n�o v�lida");

	}
	
	
	
	system("pause");	
	return 0;
}
