#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
	int matriz[4][4];
	int  vetor[4];
	int index, linha, coluna , soma =0;
	
	for (linha = 0; linha < 4;){
		for ( coluna = 0 ; coluna < 4;){
		printf("Digite o elemento: [%d][%d]", linha, coluna);
		scanf("%d", &matriz[linha][coluna]);
		if (matriz[linha][coluna] % 2 != 0){
			soma = soma + matriz[linha][coluna];
			}
		
		coluna++;
	}
	vetor[linha] = soma;
	soma = 0;
	linha++;
}
	printf("Matriz: \n");
	for (linha = 0; linha < 4;){
		for (coluna= 0; coluna <4;){
			printf("%d", matriz[linha][coluna]);
			coluna++;
		}
		printf("\n");
		linha++;
}
	printf("Vetor das somas: \n");
	for (index = 0; index < 4;){
		printf("%d", vetor[index]);
		index++;

		}
	system("pause");	
	return 0;
}
