#include <stdio.h>
#include <stdlib.h>

float peso (int P,float Kg){
		float res;
		if (P == 0){
			res = Kg * 0.37;
		}
		else if (P == 1){
			res = Kg * 0.88;
		}
		else if (P == 2){
			res = Kg * 0.38;
		}
		else if (P == 3){
			res = Kg * 2.64;
		}
		else if (P == 4){
			res = Kg * 1.15;
		}
		else if (P == 5){
			res = Kg * 1.17;
		}
		else if (P == 6){
			res = Kg * 1.18;
		}

		return res;
	}

int main(int argc, char *argv[]) 
{
	float Kg, KgF;
	int P;
	
	
	printf("Digite o seu planeta\n");
	scanf("%d", &P);
	printf("Digite o seu peso na terra\n");
	scanf("%f", &Kg);
	
	KgF = peso(P, Kg);
	
	printf("O seu peso �: %.2f Kg", KgF);
	
	


	system("pause");	
	return 0;
}

