#include <stdio.h>
#include <stdlib.h>

int main() 
{
	int vetor[5];
	int index;
	
	for (index = 0; index <5;){
		printf("digite um numero:\n");
		scanf("%d", &vetor[index]);
		index++;
	}
	
	index-=1;
	while (index >=0){
		printf("vetor[%d]: %d\n", index, vetor[index]);
		index--;
	}
	
	system("pause");	
	return 0;
}
