#ifndef DEPOSITAR_H
#define DEPOSITAR_H

#include "login.h"
#include "registrar_extrato.h"

void depositar(char *usuario_ativo) {
    // Guarda uma linha do contas.txt
    struct cadastro {
        char nome[50], cpf[12], senha[7];
        double reais, bitcoin, ethereum, ripple;
    };

    struct cadastro contas[100];
    char linha[200], ativo[50], nome_min[50];
    int total = 0, pos = -1, i;
    double valor = 0;
    FILE *arquivo;

    printf("\nDigite o valor do deposito: ");
    scanf("%lf", &valor);

    if (valor <= 0) {
        printf("Valor invalido.\n");
        return;
    }

    strcpy(ativo, usuario_ativo);
    minusculo(ativo);

    // Le todas as contas do arquivo
    arquivo = fopen("contas.txt", "r");
    if (arquivo == NULL) {
        printf("Nao foi possivel abrir o arquivo contas.txt\n");
        return;
    }

    while (total < 100 && fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (sscanf(linha, "%49[^_]_%11[^_]_%6[^_]_%lf_%lf_%lf_%lf",
                   contas[total].nome, contas[total].cpf, contas[total].senha,
                   &contas[total].reais, &contas[total].bitcoin,
                   &contas[total].ethereum, &contas[total].ripple) == 7) {
            strcpy(nome_min, contas[total].nome);
            minusculo(nome_min);
            if (strcmp(ativo, nome_min) == 0) {
                pos = total;
            }
            total++;
        }
    }
    fclose(arquivo);

    if (pos == -1) {
        printf("Conta nao encontrada (%d contas lidas do arquivo).\n", total);
        return;
    }

    // Soma o deposito no saldo do usuario
    contas[pos].reais = contas[pos].reais + valor;

    // Grava todas as contas de volta no arquivo
    arquivo = fopen("contas.txt", "w");
    if (arquivo == NULL) {
        printf("Nao foi possivel gravar o arquivo contas.txt\n");
        return;
    }
    for (i = 0; i < total; i++) {
        fprintf(arquivo, "%s_%s_%s_%.2f_%.8f_%.8f_%.8f\n",
                contas[i].nome, contas[i].cpf, contas[i].senha, contas[i].reais,
                contas[i].bitcoin, contas[i].ethereum, contas[i].ripple);
    }
    fclose(arquivo);

    registrar_extrato(contas[pos].nome, '+', valor, "REAL", 0.0, 0.0,
                      contas[pos].reais, contas[pos].bitcoin,
                      contas[pos].ethereum, contas[pos].ripple);

    printf("\nDeposito realizado com sucesso! Novo saldo em reais: %.2f\n", contas[pos].reais);
}

#endif
