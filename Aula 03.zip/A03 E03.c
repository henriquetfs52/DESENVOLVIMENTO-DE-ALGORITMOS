#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float valor, total;
	int cod;
	
	
	printf("Digite o valor da compra");
	scanf("%f", &valor);
	
	printf("Digite 0 para funcionario e 1 para cliente");
	scanf("%d", &cod);
	
	switch (cod){
		case 0:
			total = valor - valor*0.05;
			break;
		case 1:
			if (valor > 1000) {
				total = valor - valor * 0.03;
				break;
			}
}

printf("O valor apos descontos �: %2.f", total);
	system("pause");	
	return 0;
}
