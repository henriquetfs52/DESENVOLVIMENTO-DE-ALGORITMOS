#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main(void) {

	setlocale(LC_ALL, "Portuguese" );

	float altura;
	float peso;


	printf("Digite a sua altura");
	scanf("%f", &altura);

	peso = (72.7*altura) -58;

	printf("o seu peso ideal �:: %.2f \n", peso);

	system("pause");

	return 0;

}
