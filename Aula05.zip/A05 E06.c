#include <stdio.h>
#include <stdlib.h>

int main()
{
	int matriz[3][3];
	int linha, coluna , soma =0;

	for (linha = 0; linha < 3;){
		for ( coluna = 0 ; coluna < 3;){
		printf("Digite o elemento: [%d][%d]", linha, coluna);
		scanf("%d", &matriz[linha][coluna]);
		if (linha == coluna){
			soma = soma + matriz[linha][coluna];
			}

		coluna++;
	}
	linha++;
}
	printf("Matriz: \n");
	for (linha = 0; linha < 3;){
		for (coluna= 0; coluna <3;){
			printf("%d", matriz[linha][coluna]);
			coluna++;
		}
		printf("\n");
		linha++;
}
	printf("Soma diagonal: \n");

		printf("%d", soma);

	system("pause");
	return 0;
}
