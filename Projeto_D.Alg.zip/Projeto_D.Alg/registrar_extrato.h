#ifndef REGISTRAR_EXTRATO_H
#define REGISTRAR_EXTRATO_H

#include <stdio.h>
#include <time.h>

// Grava uma linha no extrato.txt com a data atual e os saldos depois da opera��o
void registrar_extrato(const char *nome, char sinal, double valor, const char *moeda,
                       double cotacao, double taxa,
                       double real, double btc, double eth, double xrp) {
    char data[20];
    time_t agora = time(NULL);
    strftime(data, sizeof(data), "%d-%m-%Y %H:%M", localtime(&agora));

    FILE *extrato = fopen("extrato.txt", "a");
    if (extrato == NULL) {
        printf("Nao foi possivel abrir o arquivo extrato.txt\n");
        return;
    }

       fprintf(extrato, "%s_%s_%c_%.2f_%s_%.2f_%.2f_%.2f_%.8f_%.8f_%.8f\n",
            nome, data, sinal, valor, moeda, cotacao, taxa, real, btc, eth, xrp);

    fclose(extrato);
}

#endif
