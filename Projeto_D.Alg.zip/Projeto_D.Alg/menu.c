#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "login.h"
#include "consultar_saldo.h"
#include "registrar_extrato.h"
#include "depositar.h"
#include "sacar.h"
#include "consultar_extrato.h"
#include "atualizar_cotacao.h"
#include "comprar_cripto.h"
#include "vender_cripto.h"

int main() {
    struct user usuario;
    char usuario_ativo[50] = "";
    int inicio = 0, menu = 0, opc_menu = 0;

    srand(time(NULL));

    printf("| Exchange Fei |\n");
    printf("Digite [1] para logar no aplicativo\n");
    printf("Digite [0] para sair do aplicativo\n");
    printf("Digito: ");
    scanf("%d", &inicio);

    if (inicio == 1) {
        if (login(&usuario)) {
            printf("\nLogin realizado com sucesso! Bem-vindo, %s.\n", usuario.nome);
            strcpy(usuario_ativo, usuario.nome);
            menu = 1;
        } else {
            printf("\nDados incorretos. Acesso negado.\n");
        }
    } else {
        return 0;
    }

    while (menu) {
        printf("\n | Seja bem-vindo ao exchange de moedas da FEI |\n");
        printf(" | Qual acao deseja realizar no aplicativo? |\n");
        printf(" 1- Consultar saldo\n");
        printf(" 2- Consultar extrato\n");
        printf(" 3- Depositar\n");
        printf(" 4- Sacar\n");
        printf(" 5- Comprar criptomoedas\n");
        printf(" 6- Vender criptomoedas\n");
        printf(" 7- Atualizar cotacao\n");
        printf(" 8- Sair\n");
        printf(" Digite sua opcao: ");

        opc_menu = 0;
        scanf("%d", &opc_menu);


        switch (opc_menu) {
            case 1:
                consultar_saldo(usuario_ativo);
                break;
            case 2:
                consultar_extrato(usuario_ativo);
                break;
            case 3:
                depositar(usuario_ativo);
                break;
            case 4:
                sacar(usuario_ativo);
                break;
            case 5:
                comprar_cripto(usuario_ativo);
                break;
            case 6:
                vender_cripto(usuario_ativo);
                break;
            case 7:
                atualizar_cotacao();
                break;
            case 8:
                menu = 0;
                printf("\nSaindo do aplicativo...\n");
                break;
            default:
                printf("\nOpcao invalida, digite novamente.\n");
        }
    }

    system("pause");
    return 0;
}
