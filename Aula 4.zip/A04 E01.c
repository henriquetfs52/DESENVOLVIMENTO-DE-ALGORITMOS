#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
	int soma = 0, n, cont = 1;
	while (cont <= 5){
		printf("escreva o %d* numero\n", cont);
		scanf("%d", &n);
		soma+= n;
		cont ++;
	}
	printf("Soma: %d\n", soma);
	system("pause");	
	return 0;
}
