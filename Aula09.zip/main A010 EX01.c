#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *vetor;
	int i;
	
	vetor = (int*) malloc(10 * sizeof(int));
	
	for (i=0; i < 10; i++){
		vetor[i] = (i + 1) * 10;
	}
	
	printf("elementos do vetor: \n");
	
	for (i=0; i < 10; i++){
		printf(" %d \n" , vetor[i]);
	}
	
	free(vetor);

	
	system("pause");	
	return 0;
}
