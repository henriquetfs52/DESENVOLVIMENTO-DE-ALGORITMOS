#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{
	char linha[100];
	int i = 0;
	
	printf("Digite a linha: ");
	fgets(linha, sizeof(linha), stdin);
	
	
    while (linha[i] != '\0') {
        linha[i] = tolower((unsigned char) linha[i]);
        i++;
    }
    
    printf("\n minusculos: ");
    printf("%s \n", linha);
    
    i = 0;
    while (linha[i] != '\0') {
        linha[i] = toupper((unsigned char) linha[i]);
        i++;
    }
    
    printf("MAIUSCULOS!!: ");
    printf("%s \n", linha);

	system("pause");	
	return 0;
}
