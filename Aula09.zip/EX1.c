#include <stdio.h>
#include <stdlib.h>

int main()
{
	FILE *mbape;
	FILE *pares;
	mbape = fopen("mbape.txt", "w");
	pares = fopen("pares.txt", "w");
	int i;
	
	
	if (mbape == NULL || pares ==NULL) {
		printf("memes!\n");
		return 1;
	}
	
	for (i=0; i < 999; i++){
		if (i%2==0){
            fprintf(pares, "%d ", i);
		}
            else {
            fprintf(mbape, "%d ", i);
		}
	}
	
	
	return 0;
}
