#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n, i;
	printf("Digite um numero")
	scanf("%d", &n);
	for (i = )
	system("pause");	
	return 0;
}
