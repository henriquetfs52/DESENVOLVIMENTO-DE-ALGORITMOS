#ifndef VENDER_CRIPTO_H
#define VENDER_CRIPTO_H

#include "login.h"
#include "registrar_extrato.h"
#include "atualizar_cotacao.h"

void vender_cripto(char *usuario_ativo) {
    // Guarda uma linha do contas.txt
    struct cadastro {
        char nome[50], cpf[12], senha[7];
        double reais, bitcoin, ethereum, ripple;
    };

    struct cadastro contas[100];
    char linha[200], ativo[50], nome_min[50], moeda[10], senha_digitada[7];
    int total = 0, pos = -1, opcao = 0, i;
    double cot_btc, cot_eth, cot_xrp;
    double cotacao, taxa, quantidade = 0, valor_bruto, custo_taxa, valor_final;
    double tem = 0;
    FILE *arquivo;

    if (ler_cotacoes(&cot_btc, &cot_eth, &cot_xrp) == 0) {
        return;
    }

    printf("\nQual criptomoeda deseja vender?\n");
    printf("1- Bitcoin  (R$ %.2f, taxa de 3%%)\n", cot_btc);
    printf("2- Ethereum (R$ %.2f, taxa de 2%%)\n", cot_eth);
    printf("3- Ripple   (R$ %.2f, taxa de 1%%)\n", cot_xrp);
    printf("Opcao: ");
    scanf("%d", &opcao);

    if (opcao == 1) {
        strcpy(moeda, "BTC");
        cotacao = cot_btc;
        taxa = 0.03;
    } else if (opcao == 2) {
        strcpy(moeda, "ETH");
        cotacao = cot_eth;
        taxa = 0.02;
    } else if (opcao == 3) {
        strcpy(moeda, "XRP");
        cotacao = cot_xrp;
        taxa = 0.01;
    } else {
        printf("Opcao invalida.\n");
        return;
    }

    printf("Quantas unidades de %s deseja vender?: ", moeda);
    scanf("%lf", &quantidade);

    if (quantidade <= 0) {
        printf("Valor invalido.\n");
        return;
    }

    strcpy(ativo, usuario_ativo);
    minusculo(ativo);

    // Le todas as contas do arquivo
    arquivo = fopen("contas.txt", "r");
    if (arquivo == NULL) {
        printf("Nao foi possivel abrir o arquivo contas.txt\n");
        return;
    }

    while (total < 100 && fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (sscanf(linha, "%49[^_]_%11[^_]_%6[^_]_%lf_%lf_%lf_%lf",
                   contas[total].nome, contas[total].cpf, contas[total].senha,
                   &contas[total].reais, &contas[total].bitcoin,
                   &contas[total].ethereum, &contas[total].ripple) == 7) {
            strcpy(nome_min, contas[total].nome);
            minusculo(nome_min);
            if (strcmp(ativo, nome_min) == 0) {
                pos = total;
            }
            total++;
        }
    }
    fclose(arquivo);

    if (pos == -1) {
        printf("Conta nao encontrada (%d contas lidas do arquivo).\n", total);
        return;
    }
    
    printf("Digite sua senha: ");
    scanf("%6s", senha_digitada);
    if (strcmp(senha_digitada, contas[pos].senha) != 0) {
        printf("Senha incorreta.\n");
        return;
    }

    // Quanto o usuario tem da moeda escolhida
    if (opcao == 1) tem = contas[pos].bitcoin;
    if (opcao == 2) tem = contas[pos].ethereum;
    if (opcao == 3) tem = contas[pos].ripple;

    // Nao da para vender mais do que se tem
    if (quantidade > tem) {
        printf("\nOperacao nao permitida: voce nao tem essa quantidade.\n");
        printf("Voce possui %.8f %s\n", tem, moeda);
        return;
    }

    // Calcula o valor da venda, a taxa e quanto o usuario recebe
    valor_bruto = quantidade * cotacao;
    custo_taxa = valor_bruto * taxa;
    valor_final = valor_bruto - custo_taxa;

    // Tira a cripto e soma os reais
    contas[pos].reais = contas[pos].reais + valor_final;
    if (opcao == 1) contas[pos].bitcoin  = contas[pos].bitcoin - quantidade;
    if (opcao == 2) contas[pos].ethereum = contas[pos].ethereum - quantidade;
    if (opcao == 3) contas[pos].ripple   = contas[pos].ripple - quantidade;

    // Grava todas as contas de volta no arquivo
    arquivo = fopen("contas.txt", "w");
    if (arquivo == NULL) {
        printf("Nao foi possivel gravar o arquivo contas.txt\n");
        return;
    }
    for (i = 0; i < total; i++) {
        fprintf(arquivo, "%s_%s_%s_%.2f_%.8f_%.8f_%.8f\n",
                contas[i].nome, contas[i].cpf, contas[i].senha, contas[i].reais,
                contas[i].bitcoin, contas[i].ethereum, contas[i].ripple);
    }
    fclose(arquivo);

    registrar_extrato(contas[pos].nome, '-', valor_bruto, moeda, cotacao, taxa,
                      contas[pos].reais, contas[pos].bitcoin,
                      contas[pos].ethereum, contas[pos].ripple);

    printf("\nVenda realizada com sucesso!\n");
    printf("Voce vendeu %.8f %s por R$ %.2f\n", quantidade, moeda, valor_bruto);
    printf("Taxa cobrada: R$ %.4f\n", custo_taxa);
    printf("Voce recebeu: R$ %.4f\n", valor_final);
    printf("Novo saldo em reais: %.2f\n", contas[pos].reais);
}

#endif
