#ifndef COMPRAR_CRIPTO_H
#define COMPRAR_CRIPTO_H

#include "login.h"
#include "registrar_extrato.h"
#include "atualizar_cotacao.h"

void comprar_cripto(char *usuario_ativo) {
    // Guarda uma linha do contas.txt
    struct cadastro {
        char nome[50], cpf[12], senha[7];
        double reais, bitcoin, ethereum, ripple;
    };

    struct cadastro contas[100];
    char linha[200], ativo[50], nome_min[50], moeda[10], senha_digitada[7];
    int total = 0, pos = -1, opcao = 0, i;
    double cot_btc, cot_eth, cot_xrp;
    double cotacao, taxa, valor = 0, custo_taxa, quantidade;
    FILE *arquivo;

    if (ler_cotacoes(&cot_btc, &cot_eth, &cot_xrp) == 0) {
        return;
    }

    printf("\nQual criptomoeda deseja comprar?\n");
    printf("1- Bitcoin  (R$ %.2f, taxa de 2%%)\n", cot_btc);
    printf("2- Ethereum (R$ %.2f, taxa de 1%%)\n", cot_eth);
    printf("3- Ripple   (R$ %.2f, taxa de 1%%)\n", cot_xrp);
    printf("Opcao: ");
    scanf("%d", &opcao);


    if (opcao == 1) {
        strcpy(moeda, "BTC");
        cotacao = cot_btc;
        taxa = 0.02;
    } else if (opcao == 2) {
        strcpy(moeda, "ETH");
        cotacao = cot_eth;
        taxa = 0.01;
    } else if (opcao == 3) {
        strcpy(moeda, "XRP");
        cotacao = cot_xrp;
        taxa = 0.01;
    } else {
        printf("Opcao invalida.\n");
        return;
    }

    printf("Quantos reais deseja gastar na compra?: ");
    scanf("%lf", &valor);

    if (valor <= 0) {
        printf("Valor invalido.\n");
        return;
    }

    strcpy(ativo, usuario_ativo);
    minusculo(ativo);

    // Le todas as contas do arquivo
    arquivo = fopen("contas.txt", "r");
    if (arquivo == NULL) {
        printf("Nao foi possivel abrir o arquivo contas.txt\n");
        return;
    }

    while (total < 100 && fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (sscanf(linha, "%49[^_]_%11[^_]_%6[^_]_%lf_%lf_%lf_%lf",
                   contas[total].nome, contas[total].cpf, contas[total].senha,
                   &contas[total].reais, &contas[total].bitcoin,
                   &contas[total].ethereum, &contas[total].ripple) == 7) {
            strcpy(nome_min, contas[total].nome);
            minusculo(nome_min);
            if (strcmp(ativo, nome_min) == 0) {
                pos = total;
            }
            total++;
        }
    }
    fclose(arquivo);

    if (pos == -1) {
        printf("Conta nao encontrada (%d contas lidas do arquivo).\n", total);
        return;
    }
    
    printf("Digite sua senha: ");
    scanf("%6s", senha_digitada);
    if (strcmp(senha_digitada, contas[pos].senha) != 0) {
        printf("Senha incorreta.\n");
        return;
    }

    // A taxa e cobrada em cima do valor gasto
    custo_taxa = valor * taxa;

    // O saldo n pode ficar negativo
    if (valor + custo_taxa > contas[pos].reais) {
        printf("\nOperacao nao permitida: o saldo nao pode ficar negativo.\n");
        printf("Saldo atual: %.2f | Valor da compra: %.2f\n", contas[pos].reais, valor);
        return;
    }

    // Quanto de cripto o usuario recebe
    quantidade = valor / cotacao;

    contas[pos].reais = contas[pos].reais - valor - custo_taxa;
    if (opcao == 1) contas[pos].bitcoin  = contas[pos].bitcoin + quantidade;
    if (opcao == 2) contas[pos].ethereum = contas[pos].ethereum + quantidade;
    if (opcao == 3) contas[pos].ripple   = contas[pos].ripple + quantidade;

    // Grava todas as contas de volta no arquivo
    arquivo = fopen("contas.txt", "w");
    if (arquivo == NULL) {
        printf("Nao foi possivel gravar o arquivo contas.txt\n");
        return;
    }
    for (i = 0; i < total; i++) {
        fprintf(arquivo, "%s_%s_%s_%.2f_%.8f_%.8f_%.8f\n",
                contas[i].nome, contas[i].cpf, contas[i].senha, contas[i].reais,
                contas[i].bitcoin, contas[i].ethereum, contas[i].ripple);
    }
    fclose(arquivo);

    registrar_extrato(contas[pos].nome, '+', valor, moeda, cotacao, taxa,
                      contas[pos].reais, contas[pos].bitcoin,
                      contas[pos].ethereum, contas[pos].ripple);

    printf("\nCompra realizada com sucesso!\n");
    printf("Voce comprou %.8f %s\n", quantidade, moeda);
    printf("Taxa cobrada: R$ %.4f\n", custo_taxa);
    printf("Novo saldo em reais: %.4f\n", contas[pos].reais);
}

#endif
