#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n, maior=0, cont=0;
	
	do {
		printf("Digite um numero:");
		scanf("%d", &n);
		if (n>maior){
			maior = n;
		}
		cont++;
	} while (cont<=5);
	
	printf("maior: %d", maior);
	
	system("pause");	
	return 0;
}
