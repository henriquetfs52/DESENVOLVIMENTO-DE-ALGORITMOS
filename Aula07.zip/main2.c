#include <stdio.h>
#include <stdlib.h>

int main()
{
	char x[10], y[10], z[10], w[10];
	float res;
	
	printf("Digite um numero");
	fgets(w, 10, stdin);
	printf("Digite um numero");
	fgets(x, 10, stdin);
	printf("Digite um numero");
	fgets(y, 10, stdin);
	printf("Digite um numero");
    fgets(z, 10, stdin);

	res = atof(x) + atof(y) + atof(z)  + atof(w);

	printf("%.2f", res);


	system("pause");
	return 0;
}
