#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


float potencia(float x, int n){
	float res = 1;
	int i;
	for (i = 0; i < n;i ++){
		res = res * x;

	}
	return res;
}

int main(void){
	float x;
	int n;
	
	setlocale(LC_ALL, "Portuguese");
	printf("digite o valor de x");
	scanf("%f", &x);
	printf("digite o valor de n");
	scanf("%d", &n);
	
	float res = potencia(x, n);
	printf("x**n= %2.f", res);





	system("pause");
	return 0;
}
