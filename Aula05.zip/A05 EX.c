#include <stdio.h>
#include <stdlib.h>

int main()
{
	int matriz[3][3];
	int linha, coluna;

	for (linha = 0; linha < 3; linha++){
		for (colunha =0; coluna < 3; coluna++){
			prinf("Digite o valor para [%d][%d]: ", linha, coluna);
			scanf("%d", &matriz[linha][coluna]);

		}
	}
	
	while (cont >=	 0){
		printf("%d", [cont]);
		cont--;
	}
	system("pause");	
	return 0;
}
