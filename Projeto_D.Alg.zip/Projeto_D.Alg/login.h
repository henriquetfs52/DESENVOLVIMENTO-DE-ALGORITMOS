#ifndef LOGIN_H
#define LOGIN_H

#include <stdio.h>
#include <string.h>
#include <ctype.h>

struct user {
    char cpf[12];
    char nome[50];
    char senha[7];
};

// Transforma o texto em letras minusculas
void minusculo(char *s) {
    int i;
    for (i = 0; s[i] != '\0'; i++) {
        s[i] = tolower((unsigned char)s[i]);
    }
}

// Retorna 1 se nome, CPF e senha existirem no usuarios.txt, 0 caso contrario
int login(struct user *p) {
    char linha[200], cpf[12], nome[50], senha[7];
    char nome_digitado[50];
    FILE *arquivo;

    printf("\nDigite seu nome: ");
    scanf(" %49[^\n]", p->nome);

    printf("\nDigite seu CPF, sem tracos ou pontos: ");
    scanf("%11s", p->cpf);

    printf("\nDigite sua senha (6 digitos): ");
    scanf("%6s", p->senha);

    strcpy(nome_digitado, p->nome);
    minusculo(nome_digitado);

    arquivo = fopen("usuarios.txt", "r");
    if (arquivo == NULL) {
        printf("Nao foi possivel abrir o arquivo usuarios.txt\n");
        return 0;
    }

    // Cada linha do arquivo: cpf_nome_senha
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (sscanf(linha, "%11[^_]_%49[^_]_%6s", cpf, nome, senha) == 3) {
            minusculo(nome);
            if (strcmp(p->cpf, cpf) == 0 &&
                strcmp(nome_digitado, nome) == 0 &&
                strcmp(p->senha, senha) == 0) {
                fclose(arquivo);
                return 1;
            }
        }
    }

    fclose(arquivo);
    return 0;
}

#endif
