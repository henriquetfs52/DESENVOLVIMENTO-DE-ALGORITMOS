#include <stdio.h>
#include <stdlib.h>

int main(){

	int *vetor;
	int N, i, x, soma=0;
	
	printf("Digite a quantidade de numeros");
	scanf("%d", &N);
	
	vetor = (int*) malloc(N * sizeof(int));
	
	for (i=0; i < N; i++){
		printf("Digite um numero");
		scanf("%d", &x);
		soma += x;
		vetor[i] = x;
	}

    for (i=0; i < N; i++){
		printf(" %d ", vetor[i]);

	}
	
	printf("\n soma: %d", soma);
	
	
	free(vetor);
	system("pause");
	return 0;
}
