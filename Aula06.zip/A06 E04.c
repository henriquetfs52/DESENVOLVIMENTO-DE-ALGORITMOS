#include <stdio.h>
#include <stdlib.h>

void modifica (int *x){
	if (*x % 2 == 0){
		*x = *x + 1;
	}	else {
		*x = *x + 2;
	}
}

int main(int argc, char *argv[]) 
{
	int a;
	
	a = 5;
	modifica(&a);
	printf("a= %d\n", a);
	system("pause");	
	return 0;
}
